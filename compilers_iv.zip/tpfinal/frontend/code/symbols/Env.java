package code.symbols;

import code.inter.Id;
import code.lexer.Token;

import java.util.HashMap;

public class Env {
    private Env prev;
    private HashMap<Token, Id> table;

    public Env(Env n) {
        prev = n;
        table = new HashMap<>();
    }

    public void put(Token w, Id i) {
        table.put(w, i);
    }

    public Id get(Token w) {
        for (Env e = this; e != null; e = e.prev) {
            Id found = e.table.get(w);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
}
