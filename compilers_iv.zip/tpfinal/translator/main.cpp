#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>

using namespace std;

#include "parser.h"
#include "translator.h"

int main(int argc, char **argv) {
  if (argc < 3) {
    cerr << "usage: ./tp3 <input> <output>" << endl;
    return -1;
  }
  char *input_path = argv[1];
  char *output_path = argv[2];
  ifstream input(input_path, ios::in);
  ofstream output(output_path, ios::out);
  if (!input) {
    cerr << "could not open " << input_path << endl;
    return -1;
  }

  translator t(output);

  string line;

  while (getline(input, line)) {
    if (line.empty()) {
      continue;
    }

    stmt s = stmt::parse(line);
    t.add(s);
  }

  t.generate();

  return 0;
}
