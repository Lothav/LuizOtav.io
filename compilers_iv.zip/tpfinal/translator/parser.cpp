#include "parser.h"

#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>

enum token_type {
  token_label,
  token_id,
  token_literal,
  token_assign,
  token_arith_op,
  token_rel_op,
  token_left_bracket,
  token_right_bracket,
  token_goto,
  token_if,
  token_iffalse,
  token_end
};

struct token {
  token_type type;
  string value;

  token(token_type t) : type(t) {}

  token(token_type t, string v) : type(t), value(v) {}
};

static bool check_token_id(const string &chunk) {
  bool r = isalpha(chunk[0]);
  for (auto i = 1; i < chunk.size(); i++) {
    r &= isalpha(chunk[i]) || isdigit(chunk[i]);
  }
  return r;
}

static bool check_token_literal(const string &chunk) {
  if (chunk == "true" || chunk == "false") return true;

  bool r = true;
  bool single_dot_found = false;
  for (auto i = 0; i < chunk.size(); i++) {
    bool valid_dot = !single_dot_found && chunk[i] == '.';
    if (valid_dot) single_dot_found = true;
    r &= valid_dot || isdigit(chunk[i]);
  }
  return r;
}

vector<token> tokenize(const string &line) {
  vector<token> r;

  string line_copy = line;

  replace(line_copy.begin(), line_copy.end(), '\t', ' ');

  // left trim
  decltype(line_copy.size()) first = 0;
  while (first < line_copy.size() && line_copy[first] == ' ') first++;
  line_copy = line_copy.substr(first);

  istringstream ss(line_copy);
  string chunk;

  while (getline(ss, chunk, ' ')) {
    if (chunk[0] == 'L') {
      string label;
      istringstream label_ss(chunk);

      while (getline(label_ss, label, ':')) {
        r.emplace_back(token_label, label.substr(1));
      }
    } else if (chunk == "if")
      r.emplace_back(token_if, chunk);
    else if (chunk == "iffalse")
      r.emplace_back(token_iffalse, chunk);
    else if (chunk == "goto")
      r.emplace_back(token_goto, chunk);
    else if (check_token_literal(chunk))
      r.emplace_back(token_literal, chunk);
    else if (check_token_id(chunk))
      r.emplace_back(token_id, chunk);
    else if (chunk == "=")
      r.emplace_back(token_assign, chunk);
    else if (chunk == "+")
      r.emplace_back(token_arith_op, chunk);
    else if (chunk == "-")
      r.emplace_back(token_arith_op, chunk);
    else if (chunk == "*")
      r.emplace_back(token_arith_op, chunk);
    else if (chunk == "/")
      r.emplace_back(token_arith_op, chunk);
    else if (chunk == "<")
      r.emplace_back(token_rel_op, chunk);
    else if (chunk == "<=")
      r.emplace_back(token_rel_op, chunk);
    else if (chunk == ">")
      r.emplace_back(token_rel_op, chunk);
    else if (chunk == ">=")
      r.emplace_back(token_rel_op, chunk);
    else if (chunk == "==")
      r.emplace_back(token_rel_op, chunk);
    else if (chunk == "!=")
      r.emplace_back(token_rel_op, chunk);

    else if (chunk == "[")
      r.emplace_back(token_left_bracket, chunk);
    else if (chunk == "]")
      r.emplace_back(token_right_bracket, chunk);
    else
      throw tokenization_error("unrecognized token");
  }

  r.push_back(token_end);

  return r;
}

string consume_token(const vector<token> &v, vector<token>::iterator &it,
                     token &t, token_type type) {
  if (it == v.end() || (t = (*it++)).type != type) {
    throw tokenization_error("unexpected token");
  }

  return t.value;
}

stmt stmt::parse(const string &line) {
  stmt s;
  stringstream ss;

  vector<token> tokens = tokenize(line);
  auto it = tokens.begin();

  token &t = *it++;
  while (t.type == token_label) {
    uint32_t label;
    ss.clear();
    ss << t.value;
    ss >> label;
    s.input_labels.push_back(label);

    t = *it++;
  }

  if (t.type == token_end) {
    s.type = stmt_empty;
  } else if (t.type == token_if || t.type == token_iffalse) {
    s.type = t.type == token_if ? stmt_if : stmt_iffalse;

    t = *it++;
    s.is_op_a_id = false;
    if (t.type == token_literal)
      s.op_a = t.value;
    else if (t.type == token_id) {
      s.op_a = t.value;
      s.is_op_a_id = true;
    }

    t = *it++;

    if (t.type == token_rel_op) {
      s.op = t.value;

      t = *it++;
      s.is_op_b_id = false;
      if (t.type == token_literal)
        s.op_b = t.value;
      else if (t.type == token_id) {
        s.op_b = t.value;
        s.is_op_b_id = true;
      }

      consume_token(tokens, it, t, token_goto);
      s.goto_ = consume_token(tokens, it, t, token_label);
    } else if (t.type == token_goto) {
      s.goto_ = consume_token(tokens, it, t, token_label);
    }
    consume_token(tokens, it, t, token_end);
  } else if (t.type == token_goto) {
    s.type = stmt_goto;
    s.goto_ = consume_token(tokens, it, t, token_label);
    consume_token(tokens, it, t, token_end);
  } else if (t.type == token_id) {
    s.dst = t.value;

    t = *it++;
    if (t.type == token_assign) {
      t = *it++;

      s.is_op_a_id = false;
      if (t.type == token_literal)
        s.op_a = t.value;
      else if (t.type == token_id) {
        s.op_a = t.value;
        s.is_op_a_id = true;
      } else
        parsing_error("unexpected token for op_a");

      t = *it++;
      if (t.type == token_end) {
        s.type = s.is_op_a_id ? stmt_assign_to_id_id : stmt_assign_to_id_num;
      } else if (t.type == token_arith_op) {
        s.op = t.value;
        s.type = stmt_assign_to_id_expr;

        t = *it++;
        s.is_op_b_id = false;
        if (t.type == token_literal)
          s.op_b = t.value;
        else if (t.type == token_id) {
          s.op_b = t.value;
          s.is_op_b_id = true;
        } else
          parsing_error("unexpected token for op_b");

        consume_token(tokens, it, t, token_end);
      } else if (t.type == token_left_bracket) {
        s.type = stmt_assign_to_id_array_elm;
        s.op_b = consume_token(tokens, it, t, token_id);
        consume_token(tokens, it, t, token_right_bracket);
        consume_token(tokens, it, t, token_end);
      }
    } else if (t.type == token_left_bracket) {
      s.type = stmt_assign_to_array_elm;
      s.op_a = consume_token(tokens, it, t, token_id);
      consume_token(tokens, it, t, token_right_bracket);
      consume_token(tokens, it, t, token_assign);
      t = *it++;
      s.is_op_b_id = false;
      if (t.type == token_literal)
        s.op_b = t.value;
      else if (t.type == token_id) {
        s.op_b = t.value;
        s.is_op_b_id = true;
      } else
        parsing_error("unexpected token for op_b");
      consume_token(tokens, it, t, token_end);
    } else
      throw parsing_error("unexpected token after id");
  } else
    throw parsing_error("unexpected initial token");

  return s;
}
