#include <sstream>
#include <vector>

#include "parser.h"
#include "translator.h"

void label_handler::fill_label(stmt &s) {
  if (s.input_labels.empty()) return;

  auto label = next_label++;

  for (const auto &orig : s.input_labels) {
    m_[orig] = label;
  }

  s.label = label;
}

void label_handler::fill_jmp(stmt &s) {
  switch (s.type) {
    case stmt_if:
    case stmt_iffalse:
    case stmt_goto: {
      uint32_t orig;
      istringstream ss(s.goto_);
      ss >> orig;

      if (!m_.count(orig)) {
        throw runtime_error("label not found");
      }

      s.goto_label = m_[orig];
      break;
    }
    default:
      break;
  }
}

static const string HEADER = R"(.version 50 0
.class public super Main
.super java/lang/Object

.method public <init> : ()V
    .code stack 1 locals 1
        aload_0
        invokespecial Method java/lang/Object <init> ()V
        return
    .end code
.end method

.method public static main : ([Ljava/lang/String;)V
)";

static const string FOOTER = R"(
        getstatic Field java/lang/System out Ljava/io/PrintStream;
        dload_0
        invokevirtual Method java/io/PrintStream println (D)V
        return
    .end code
.end method
.sourcefile 'Main.java'
.end class
)";

void translator::add(stmt &s) {
  lh.fill_label(s);
  stmts.push_back(s);

  auto create_variable = [&](const string &name) {
    if (name.empty()) return;

    if (variables.count(name)) return;

    variables[name] = next_variable;

    // The resulting code uses doubles, which are two bytes wide.
    next_variable += 2;
  };

  create_variable(s.dst);
  if (s.is_op_a_id) create_variable(s.op_a);
  if (s.is_op_b_id) create_variable(s.op_b);
}

static string format_literal(string &op) {
  if      (op == "true")  op = "1";
  else if (op == "false") op = "0";

  double val;
  istringstream iss(op);
  stringstream ss;
  iss >> val;

  ss << val;
  auto s = ss.str();
  if (s.find('.') == string::npos) s = s + ".0";
  return s;
}

void translator::generate() {
  auto n_locals = next_variable + 16;

  stream_ << HEADER;
  stream_ << "\t.code stack 8 locals " << n_locals << endl;

  static const string t = "\t\t";

  const int array_size = 1024;

  auto initialize_array = [&](const string &name) {
    auto dst_var = variables[name];

    if (!initialized_arrays.count(dst_var)) {
      initialized_arrays.insert(dst_var);
      stream_ << t << "sipush " << array_size << endl;
      stream_ << t << "newarray double" << endl;
      stream_ << t << "astore " << dst_var << endl;
    }
  };

  auto initialize_variable = [&](const string &name) {
      auto dst_var = variables[name];

      if (!initialized_variables.count(dst_var)) {
        initialized_variables.insert(dst_var);
        stream_ << t << "ldc2_w 0.0" << endl;
        stream_ << t << "dstore " << dst_var << endl;
      }
  };

  for (auto i = 0; i < stmts.size(); i++) {
    stmt &s = stmts[i];

    lh.fill_jmp(s);

    if (s.label) {
      stream_ << "L" << s.label << ":";
    }

    switch (s.type) {
      case stmt_assign_to_id_num: {
        stream_ << t << "ldc2_w " << format_literal(s.op_a) << endl;
        stream_ << t << "dstore " << variables[s.dst] << endl;
        initialized_variables.insert(variables[s.dst]);
        break;
      }
      case stmt_assign_to_id_id: {
        initialize_variable(s.op_a);
        stream_ << t << "dload " << variables[s.op_a] << endl;
        stream_ << t << "dstore " << variables[s.dst] << endl;
        initialized_variables.insert(variables[s.dst]);
        break;
      }
      case stmt_assign_to_id_expr: {
        if (s.is_op_a_id) {
          initialize_variable(s.op_a);
          stream_ << t << "dload " << variables[s.op_a] << endl;
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_a) << endl;

        if (s.is_op_b_id) {
          initialize_variable(s.op_b);
          stream_ << t << "dload " << variables[s.op_b] << endl;
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_b) << endl;

        if (s.op == "+")
          stream_ << t << "dadd" << endl;
        else if (s.op == "-")
          stream_ << t << "dsub" << endl;
        else if (s.op == "*")
          stream_ << t << "dmul" << endl;
        else if (s.op == "/")
          stream_ << t << "ddiv" << endl;

        stream_ << t << "dstore " << variables[s.dst] << endl;
        initialized_variables.insert(variables[s.dst]);
        break;
      }
      case stmt_assign_to_id_array_elm: {
        initialize_array(s.op_a);

        initialize_variable(s.op_b);
        stream_ << t << "dload " << variables[s.op_b] << endl;
        stream_ << t << "ldc2_w " << format_literal(stmts[i - 1].op_b) << endl;
        stream_ << t << "ddiv" << endl;
        stream_ << t << "dstore " << next_variable << endl;

        stream_ << t << "aload " << variables[s.op_a] << endl;
        stream_ << t << "dload " << next_variable << endl;
        stream_ << t << "d2i" << endl;
        stream_ << t << "daload" << endl;
        stream_ << t << "dstore " << variables[s.dst] << endl;
        initialized_variables.insert(variables[s.dst]);
        break;
      }
      case stmt_assign_to_array_elm: {
        initialize_array(s.dst);

        initialize_variable(s.op_a);
        stream_ << t << "dload " << variables[s.op_a] << endl;
        stream_ << t << "ldc2_w " << format_literal(stmts[i - 1].op_b) << endl;
        stream_ << t << "ddiv" << endl;
        stream_ << t << "dstore " << next_variable << endl;

        stream_ << t << "aload " << variables[s.dst] << endl;
        stream_ << t << "dload " << next_variable << endl;
        stream_ << t << "d2i" << endl;

        if (s.is_op_b_id) {
          initialize_variable(s.op_b);
          stream_ << t << "dload " << variables[s.op_b] << endl;
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_b) << endl;

        stream_ << t << "dastore" << endl;

        break;
      }
      case stmt_if: {
        if (s.is_op_a_id) {
          initialize_variable(s.op_a);
          stream_ << t << "dload " << variables[s.op_a] << endl;
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_a) << endl;

        string op = s.op;

        if (s.is_op_b_id) {
          initialize_variable(s.op_b);
          stream_ << t << "dload " << variables[s.op_b] << endl;
        }
        else if (s.op.empty()) {
          stream_ << t << "ldc2_w 0.0" << endl;
          op = "!=";
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_b) << endl;

        stream_ << t << "dcmpl" << endl;

        string inst;

        if (op == "<")
          inst = "iflt";
        else if (op == ">")
          inst = "ifgt";
        else if (op == "<=")
          inst = "ifle";
        else if (op == ">=")
          inst = "ifge";
        else if (op == "!=")
          inst = "ifne";
        else /* if (op == "==") */
          inst = "ifeq";

        stream_ << t << inst << " L" << s.goto_label << endl;

        break;
      }
      case stmt_iffalse: {
        if (s.is_op_a_id) {
          initialize_variable(s.op_a);
          stream_ << t << "dload " << variables[s.op_a] << endl;
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_a) << endl;

        string op = s.op;

        if (s.is_op_b_id) {
          initialize_variable(s.op_b);
          stream_ << t << "dload " << variables[s.op_b] << endl;
        }
        else if (s.op.empty()) {
          stream_ << t << "ldc2_w 0.0" << endl;
          op = "!=";
        }
        else
          stream_ << t << "ldc2_w " << format_literal(s.op_b) << endl;

        stream_ << t << "dcmpl" << endl;

        string inst;

        if (op == "<")
          inst = "ifge";
        else if (op == ">")
          inst = "ifle";
        else if (op == "<=")
          inst = "ifgt";
        else if (op == ">=")
          inst = "iflt";
        else if (op == "!=")
          inst = "ifeq";
        else /* if (op == "==") */
          inst = "ifne";

        stream_ << t << inst << " L" << s.goto_label << endl;

        break;
      }
      case stmt_goto: {
        stream_ << t << "goto L" << s.goto_label << endl;
        break;
      }
      case stmt_empty: {
        stream_ << t << "nop" << endl;
        break;
      }
    }
  }

  stream_ << FOOTER;
}
