#ifndef TP3_PARSER_H
#define TP3_PARSER_H

#include <cinttypes>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;

class tokenization_error : public std::runtime_error {
 public:
  tokenization_error(const char *s) : runtime_error(s) {}
};

class parsing_error : public runtime_error {
 public:
  parsing_error(const char *s) : runtime_error(s) {}
};

enum stmt_type {
  stmt_assign_to_id_id,
  stmt_assign_to_id_num,
  stmt_assign_to_id_expr,
  stmt_assign_to_id_array_elm,
  stmt_assign_to_array_elm,
  stmt_if,
  stmt_iffalse,
  stmt_goto,
  stmt_empty
};

struct stmt {
  vector<uint32_t> input_labels;
  uint32_t label;

  stmt_type type;
  string dst;
  string op;
  string op_a;
  string op_b;

  bool is_op_a_id;
  bool is_op_b_id;

  string goto_;
  uint32_t goto_label;

  stmt()
      : label(0),
        type(stmt_empty),
        dst(""),
        op(""),
        op_a(""),
        op_b(""),
        goto_("") {
    input_labels.resize(0);
  }

  static stmt parse(const string &line);
};

#endif  // TP3_PARSER_H
