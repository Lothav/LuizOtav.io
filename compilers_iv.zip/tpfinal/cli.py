#!/usr/bin/python

import os
import sys
from subprocess import check_call

JAVA = 'java'
JAVAC = 'javac'
CMAKE = 'cmake'
PYTHON = 'python2'

FRONTEND_BUILD_DIR = os.path.join('frontend', 'build')
TRANSLATOR_BUILD_DIR = os.path.join('translator', 'build')

PATH = os.path.dirname(os.path.abspath(__file__))


def build_frontend():
	print('build_frontend...')
	java_files = []

	for path, dirs, files in os.walk('frontend'):
		for filename in files:
			if filename.endswith('.java'):
				java_files.append(os.path.join(path, filename))

	cmd = [JAVAC] + java_files + ['-d', FRONTEND_BUILD_DIR]
	print(' '.join(cmd))

	try:
		os.makedirs(FRONTEND_BUILD_DIR)

	except OSError:
		pass

	check_call(cmd)


def build_translator():
	print('build_translator...')

	try:
		os.makedirs(TRANSLATOR_BUILD_DIR)

	except OSError:
		pass

	os.chdir(TRANSLATOR_BUILD_DIR)

	try:
		check_call(['cmake', os.path.pardir])
		check_call(['make'])

	finally:
		os.chdir(PATH)


def compile_small_l_file(path):
	if not os.path.isfile(path):
		sys.stderr.write('invalid path: %s\n' % path)
		sys.exit(-1)

	basename = os.path.splitext(os.path.basename(path))[0]
	output_dir = os.path.join('out', basename)

	try:
		os.makedirs(output_dir)

	except OSError:
		pass

	ir_path = os.path.join(output_dir, 'Main.ir')
	j_path = os.path.join(output_dir, 'Main.j')

	with open(ir_path, 'w') as ir_fd:
		check_call([JAVA, '-cp', FRONTEND_BUILD_DIR, 'code.main.Main', path], stdout=ir_fd)

	translator_bin_path = os.path.join(TRANSLATOR_BUILD_DIR, 'translator')

	check_call([translator_bin_path, ir_path, j_path])

	krakatau_path = os.path.join('translator', 'krakatau', 'assemble.py')

	check_call([PYTHON, krakatau_path, j_path, '-out', output_dir])

	return output_dir

def show_usage_and_exit():
	sys.stderr.write('usage: ./cli.py [build|build_translator|build_frontend|compile|run]\n')
	sys.exit(-1)


def main():
	os.chdir(PATH)
	argc = len(sys.argv)
	if argc < 2:
		show_usage_and_exit()
		return

	cmd = sys.argv[1]

	if cmd == 'build':
		build_frontend()
		build_translator()

	elif cmd == 'build_frontend':
		build_frontend()

	elif cmd == 'build_translator':
		build_translator()

	elif cmd == 'compile':
		if argc < 3:
			sys.stderr.write('usage: ./cli.py compile <path_to_file>\n')
			sys.exit(-1)
			return

		path = sys.argv[2]
		output_dir = compile_small_l_file(path)

		print('')
		print('...')
		print('Compilation done.')
		print('Result available @ %s' % output_dir)
		print('You can execute it with:')
		print('')
		print('%s -cp %s Main' % (JAVA, output_dir))

	elif cmd == 'run':
		if argc < 3:
			sys.stderr.write('usage: ./cli.py compile <path_to_file>\n')
			sys.exit(-1)
			return

		path = sys.argv[2]
		output_dir = compile_small_l_file(path)
		print('')
		check_call([JAVA, '-cp', output_dir, 'Main'])

	else:
		if argc < 3:
			sys.stderr.write('usage: ./cli.py compile <path_to_file>\n')
			sys.exit(-1)
			return

if __name__ == '__main__':
	main()

