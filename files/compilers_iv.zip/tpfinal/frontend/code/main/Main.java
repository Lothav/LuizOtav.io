package code.main;

import code.lexer.Lexer;
import code.parser.Parser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Main {
    public static void main(String[] args) throws IOException {
        InputStream in = System.in;
        if (args.length > 0) in = new FileInputStream(args[0]);
        Lexer lex = new Lexer(in);
        Parser parse = new Parser(lex);
        parse.program();
        System.out.write('\n');
    }
}
