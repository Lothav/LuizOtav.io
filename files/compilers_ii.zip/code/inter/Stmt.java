package code.inter;

public class Stmt extends Node {
    public static Stmt Null = new Stmt();
    public static Stmt Enclosing = Stmt.Null;
    int after = 0;

    public Stmt() {
    }

    public void gen(int b, int a) {
    }
}
