//
// Created by Ivan Júnior on 11/12/17.
//

#ifndef TP3_GENERATOR_H
#define TP3_GENERATOR_H

#include <cinttypes>
#include <map>
#include <set>

#include "parser.h"

class label_handler {
 private:
  map<uint32_t, uint32_t> m_;
  uint32_t next_label;

 public:
  label_handler() {
    m_.clear();
    next_label = 1;
  }

  void fill_label(stmt &s);
  void fill_jmp(stmt &s);
};

class translator {
 private:
  ostream &stream_;
  label_handler lh;
  vector<stmt> stmts;
  set<uint32_t> arrays;

  map<string, uint32_t> variables;
  uint32_t next_variable = 0;

 public:
  translator(ostream &s) : stream_(s) {}

  void add(stmt &s);
  void generate();
};

#endif  // TP3_GENERATOR_H
