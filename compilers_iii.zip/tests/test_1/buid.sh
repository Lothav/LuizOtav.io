java -cp ~/Dropbox/compiladores/smallL/build/ code.main.Main Main.sl > Main.ir
 ~/Dropbox/compiladores/tp3/build/tp3 Main.ir Main.j
python2 ~/Dropbox/compiladores/tp3/krakatau/assemble.py Main.j
/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home/bin/java Main 
